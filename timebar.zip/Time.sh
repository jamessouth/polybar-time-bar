#!/usr/bin/env bash

declare -a COLORS=(

)

IFS=\. read -a flds <<< $(awk 'BEGIN{split(strftime("%T"),a,":");f=(a[1]/24+a[2]/1440+a[3]/86400)*'$1';printf "%.6f", f}')

W=${flds[0]}

printf -v DT '%(%F)T %(%T)T'
LEN=${#DT}
FIRSTSPACE=$(($1-($1-$W)))
BEG=$((($1/2) - ($LEN/2)))

DARK=#002b36
LIGHT=#fdf6e3

for ((i=0; i<$1; i++)); do
  if [[ $i -ge $FIRSTSPACE && $i -ge $BEG && $i -lt $(($BEG + $LEN)) ]];
    then WHOLE+=%{B-}%{F$LIGHT}${DT:$(($i-$BEG)):1}
  elif [[ $i -ge $FIRSTSPACE ]];
    then WHOLE+=%{B-} ;# ⬅ insert no-break space (U+00A0) at end
  elif [[ $i -lt $FIRSTSPACE && $i -ge $BEG && $i -lt $(($BEG + $LEN)) ]];
    then WHOLE+=%{B${COLORS[$i]}}%{F$DARK}${DT:$(($i-$BEG)):1}
  else WHOLE+=%{B${COLORS[$i]}} ;# ⬅ insert no-break space (U+00A0) at end
  fi
done
WHOLE+=%{B-}
printf '%s' "$WHOLE"
