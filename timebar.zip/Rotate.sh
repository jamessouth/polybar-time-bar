#!/usr/bin/env bash

declare -a COLORS=(

)

IFS=\. read -a flds <<< $(awk 'BEGIN{split(strftime("%T"),a,":");s='$1';t=strftime("%s");f=(a[1]/24+a[2]/1440+a[3]/86400)*s;printf "%.6f.%d", f, t%s}')

W=${flds[0]}
P=${flds[1]}
I=${flds[2]}

EIGHTH=$((10#$P*8/1000000))
SPACES=$(($1-$W-1))
(($EIGHTH)) && printf -v PORTION '\\U258%X' $((16 - $EIGHTH)) || PORTION=" "
for ((i=0; i<$W; i++)); do WHOLE+=${COLORS[($i+$I) % $1]}█; done
WHOLE+=${COLORS[($W+$I) % $1]}
printf '%s%b%*s' "$WHOLE" "$PORTION" $SPACES ''
