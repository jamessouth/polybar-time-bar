#!/usr/bin/env bash

IFS=\. read -a flds <<< $(awk 'BEGIN{split(strftime("%T"),a,":");f=(a[1]/24+a[2]/1440+a[3]/86400)*'$1';printf "%.6f", f}')

W=${flds[0]}
P=${flds[1]}

EIGHTH=$((10#$P*8/1000000))
SPACES=$(($1-$W-1))
(($EIGHTH)) && printf -v PORTION '\\U258%X' $((16 - $EIGHTH)) || PORTION=" "
for ((i=0; i<$W; i++)); do printf -v C '%%{F#a4%04x}' $(($i*49));WHOLE+=${C}█; done
printf '%s%b%*s' "$WHOLE" "$PORTION" $SPACES ''
