#!/usr/bin/env bash

declare -a COLORS=(

)

IFS=\. read -a flds <<< $(awk 'BEGIN{split(strftime("%T"),a,":");f=(a[1]/24+a[2]/1440+a[3]/86400)*'$1';printf "%.6f", f}')

W=${flds[0]}

SPACES=$(($1-$W))
for ((i=0; i<$W-1; i++)); do
  if [[ $((($i+1) % 5)) -eq 0 ]];
  then WHOLE+=%{B${COLORS[($i/5)+1]}}
    else WHOLE+=%{F${COLORS[$i/5]}}█;
  fi
done
WHOLE+=%{F${COLORS[($W-1)/5]}}%{B-}
printf '%s%*s' "$WHOLE" $SPACES ''
