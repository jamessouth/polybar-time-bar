#!/usr/bin/env bash

declare -a COLORS=(
"%{F#ff0000}"
"%{F#ff0200}"
"%{F#ff0600}"
"%{F#ff0c00}"
"%{F#ff1200}"
"%{F#ff1900}"
"%{F#ff1f00}"
"%{F#ff2500}"
"%{F#ff2c00}"
"%{F#ff3200}"
"%{F#ff3800}"
"%{F#ff3f00}"
"%{F#ff4500}"
"%{F#ff4b00}"
"%{F#ff5100}"
"%{F#ff5700}"
"%{F#ff5d00}"
"%{F#ff6300}"
"%{F#ff6900}"
"%{F#ff6e00}"
"%{F#ff7500}"
"%{F#ff7b00}"
"%{F#ff8000}"
"%{F#ff8600}"
"%{F#ff8c00}"
"%{F#ff9100}"
"%{F#ff9700}"
"%{F#ff9c00}"
"%{F#ffa200}"
"%{F#ffa900}"
"%{F#ffaf00}"
"%{F#ffb400}"
"%{F#ffb900}"
"%{F#ffbe00}"
"%{F#ffc400}"
"%{F#ffca00}"
"%{F#ffd000}"
"%{F#ffd500}"
"%{F#ffdb00}"
"%{F#ffe000}"
"%{F#ffe600}"
"%{F#ffec00}"
"%{F#fff100}"
"%{F#fff600}"
"%{F#fefc00}"
"%{F#f8fe00}"
"%{F#eeff00}"
"%{F#e2ff00}"
"%{F#d7ff00}"
"%{F#ccff00}"
"%{F#c1ff00}"
"%{F#b6ff00}"
"%{F#aaff00}"
"%{F#9fff00}"
"%{F#94ff00}"
"%{F#88ff00}"
"%{F#7dff00}"
"%{F#71ff00}"
"%{F#65ff00}"
"%{F#5aff00}"
"%{F#4eff00}"
"%{F#42ff00}"
"%{F#35ff00}"
"%{F#28ff00}"
"%{F#1cff00}"
"%{F#0eff00}"
"%{F#02ff00}"
"%{F#00ff00}"
"%{F#00ff04}"
"%{F#00ff0f}"
"%{F#00ff1d}"
"%{F#00ff2a}"
"%{F#00ff36}"
"%{F#00ff42}"
"%{F#00ff4e}"
"%{F#00ff5b}"
"%{F#00ff66}"
"%{F#00ff72}"
"%{F#00ff7e}"
"%{F#00ff89}"
"%{F#00ff95}"
"%{F#00ffa0}"
"%{F#00ffac}"
"%{F#00ffb7}"
"%{F#00ffc2}"
"%{F#00ffcd}"
"%{F#00ffd9}"
"%{F#00ffe4}"
"%{F#00ffef}"
"%{F#00fef9}"
"%{F#00f8fe}"
"%{F#00edff}"
"%{F#00e2ff}"
"%{F#00d7ff}"
"%{F#00ccff}"
"%{F#00c0ff}"
"%{F#00b6ff}"
"%{F#00abff}"
"%{F#009fff}"
"%{F#0093ff}"
"%{F#0087ff}"
"%{F#007cff}"
"%{F#0071ff}"
"%{F#0065ff}"
"%{F#0059ff}"
"%{F#004eff}"
"%{F#0041ff}"
"%{F#0034ff}"
"%{F#0028ff}"
"%{F#001cff}"
"%{F#000fff}"
"%{F#0004ff}"
"%{F#0000ff}"
"%{F#0400ff}"
"%{F#1000ff}"
"%{F#1d00ff}"
"%{F#2900ff}"
"%{F#3600ff}"
"%{F#4200ff}"
"%{F#4e00ff}"
"%{F#5a00ff}"
"%{F#6600ff}"
"%{F#7300ff}"
"%{F#7e00ff}"
"%{F#8800ff}"
"%{F#9400ff}"
"%{F#a000ff}"
"%{F#ac00ff}"
"%{F#b700ff}"
"%{F#c200ff}"
"%{F#cd00ff}"
"%{F#d800ff}"
"%{F#e300ff}"
"%{F#ee00ff}"
"%{F#f800ff}"
)

FUT=$(date -d "$2" +%s)
REF=$(($FUT - $(printf '%(%s)T')))
FLASHCOUNT=0

while true; do
  CUR=$(($FUT - $(printf '%(%s)T')))
  if [[ $CUR -gt 0 ]]; then
    IFS=\. read -a flds <<< $(awk 'BEGIN{f=(1-'$CUR'/'$REF')*'$1';printf "%.6f", f}')

    W=${flds[0]}
    P=${flds[1]}

    EIGHTH=$((10#$P*8/1000000))
    SPACES=$(($1-$W-1))
    (($EIGHTH)) && printf -v PORTION '\\U258%X' $((16 - $EIGHTH)) || PORTION=" "
    for ((i=0; i<$W; i++)); do WHOLE+=${COLORS[$i]}█; done
    WHOLE+=${COLORS[$W]}
    printf '%s%b%*s\n' "$WHOLE" "$PORTION" $SPACES ''
    WHOLE=""
  else
    if [[ $FLASHCOUNT -lt $4 ]]; then
      if [[ $(($CUR % 2)) -eq 0 ]]; then
        REV=%{R}
      else
        REV=""
      fi
      LEN=${#3}
      SPACES=$((($1-$LEN)/2))
      printf '%s%*s%s%*s\n' "$REV" $SPACES '' "$3" $SPACES ''
    else
      echo
    fi
    ((FLASHCOUNT++))
  fi
  sleep 1 &# ⬅ interval set here
  wait
done
