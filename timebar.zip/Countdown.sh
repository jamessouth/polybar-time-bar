#!/usr/bin/env bash

declare -a COLORS=(

)

FUT=$(date -d "$2" +%s)
REF=$(($FUT - $(printf '%(%s)T')))
FLASHCOUNT=0

while true; do
  CUR=$(($FUT - $(printf '%(%s)T')))
  if [[ $CUR -gt 0 ]]; then
    IFS=\. read -a flds <<< $(awk 'BEGIN{f=(1-'$CUR'/'$REF')*'$1';printf "%.6f", f}')

    W=${flds[0]}
    P=${flds[1]}

    EIGHTH=$((10#$P*8/1000000))
    SPACES=$(($1-$W-1))
    (($EIGHTH)) && printf -v PORTION '\\U258%X' $((16 - $EIGHTH)) || PORTION=" "
    for ((i=0; i<$W; i++)); do WHOLE+=${COLORS[$i]}█; done
    WHOLE+=${COLORS[$W]}
    printf '%s%b%*s\n' "$WHOLE" "$PORTION" $SPACES ''
    WHOLE=""
  else
    if [[ $FLASHCOUNT -lt $4 ]]; then
      if [[ $(($CUR % 2)) -eq 0 ]]; then
        REV=%{R}
      else
        REV=""
      fi
      LEN=${#3}
      SPACES=$((($1-$LEN)/2))
      printf '%s%*s%s%*s\n' "$REV" $SPACES '' "$3" $SPACES ''
    else
      echo
    fi
    ((FLASHCOUNT++))
  fi
  sleep 1 &# ⬅ interval set here
  wait
done
